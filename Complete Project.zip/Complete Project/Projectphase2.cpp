#include<iostream>
#include<iomanip>
#include<fstream>
#include<conio.h>


using namespace std;
// Function to Add a contact
class contact
{
long phone;
char name[20],add[20],email[30];
void Addcontact()
{

            cout<<"Phone No: ";
            cin>>phone;

            cout<<"Name: ";
           cin.ignore();
            cin>>name;
           
			cout<<"Address: ";
            cin.ignore();
            cin>>add;
           
            cout<<"Email address: ";
            cin.ignore();
            cin>>email;
           
}
void show_contact()
{
    cout<<endl<<"Phone #: "<<phone;
		cout<<endl<<"Name: "<<name;
		cout<<endl<<"Address: "<<add;
		cout<<endl<<"Email Address : "<<email;
}
long getPhone()
	{
		return phone;
	}
	
	char* getName()
	{
		return name;
	}
	
	char* getAddress()
	{
		return add;
	}
	
	char* getEmail()
	{
		return email;
	}
}
contact cont;
// Function to Search for contact
void Searchcn(int num)
{
  bool found;
  int ch;
  if(cont==num)
  {
    cout<<cont;
    found=true;
  }
  else if(found==false)
  {
    cout<<"Contact not found";
  }

}

// Function to show List of all contacts
void Cnlist()
{
  system("cls");
	 cout<<"\n\t\t================================\n\t\t\tLIST OF CONTACTS\n\t\t================================\n";
	 system("CLS");
           
     cout<<left<<setw(10)<<"Phone"<<left<<setw(10)<<"Name"<<left<<setw(20)<<"Address"<<left<<setw(40)<<"Email"<<endl;
    
     cout<<left<<setw(10)<<phone<<left<<setw(10)<<name[i]<<left<<setw(20)<<add[i]<<left<<setw(40)<<email[i]<<endl;  
    
            	cout<<endl<<"=================================================\n"<<endl;
	
}

// Function to Update a contact
void Updatecn()
{
int num;
	bool found=false;
	system("cls");
	cout<<"..::Update contact\n===============================\n\n\t..::Enter the number of contact to update:";
    cin>>num;
 if (num == phone)
                {
                    cout << "Enter the new phone no : ";
                    cin >> updatephone;
                    updatephone = num;
                    cout<<"Phone no updated successfully.";
}
if(num==name[i])
{
  cout<<"Enter the new name :";
  cin>>updatename;
  updatename=num;
  cout<<"Name updated successfully.";
}
if(num==add[i])
{
  cout<<"Enter the new address:";
  cin>>updateadd;
  updateadd=num;
  cout<<"Address updated successfully."
}
if(num==email[i])
{
  cout<<"Enter the new email:";
cin>>updateemail;
updateemail=num;
cout<<"Email updated successfully.";
}

// Function to Delete a contact
void Deletecn();
int num;
	system("cls");
	cout<<endl<<endl<<"Please Enter The contact no: ";
	cin>>num;
  int i;
  for(int i=0;i<15;i++)
  {
    phone=""<<endl;
    name[i]=""<<endl;
    add[i]=""<<endl;
    email[i]=""<<endl;
    getch();
  }
// Function to Validate contact number
void Validatecn()
{
  {
    bool isvalidatePhone(long phone)
    {
      int z=name.length();
    bool flag;
    if(p<=13)
    {
        for(int i=0;i<p;i++)
        {
    if((phone[0]=='+'&&phone[1]=='9'&&phone[2]=='2'&&phone[3]=='3'&&
    (phone[4]=='0'||phone[4]=='1'||phone[4]=='2'||phone[4]=='3'||phone[4]=='4')&&
    (phone[5]>='0'&&phone[5]<='9')&&
    (phone[6]>='0'&&phone[6]<='9')&&
    (phone[7]>='0'&&phone[7]<='9')&&
    (phone[8]>='0'&&phone[8]<=9)&&
    (phone[9]>='0'&&phone[9]<=9)&&
    (phone[10]>='0'&&phone[10]<=9)&&
    (phone[11]>='0'&&phone[11]<=9)&&
    (phone[12]>='0'&&phone[12]<=9)))
   
    {
        flag=true;
    }
    
    else
    {
      flag=false;
      break;
    }
        }
    }
    else
    {
        flag=false;
    }
    return flag;
    }
  }

  {
  bool isvalidName(char name)
  {
  int z=name.length();
    bool flag;
    if(z<=20)
    {
        for(int i=0;i<z;i++)
        {
    if((name[i]>='A'&&name[i]<='Z')||(name[i]>='a'&&name[i]<='z')||(name[i]>=' '))
    {
        flag=true;
    }
    else
    {
      flag=false;
      break;
    }
        }
    }
    else
    {
        flag=false;
    }
    return flag;
    }
  }
  {
    bool isvalidAdd(char add)
    {
      int s=name.length();
    bool flag;
    if(s<=20)
    {
        for(int i=0;i<s;i++)
        {
    if((add[i]>='A'&&add[i]<='Z')||(add[i]>='a'&&add[i]<='z')||(add[i]>=' ')||(add[i]>0&add[i]<9)||(add[i]=="#"||add[i]=="-"))
    {
        flag=true;
    }
    else
    {
      flag=false;
      break;
    }
        }
    }
    else
    {
        flag=false;
    }
    return flag;
    } 
  }
    {
      bool isvalidEmail(char email)
      {
        int x=name.length();
    bool flag;
    if(x<=30)
    {
        for(int i=0;i<x;i++)
        {
    if((email[i]>='A'&&email[i]<='Z')||(email[i]>='a'&&email[i]<='z')||(email[i]>='.')||(email[i]"@"))
    {
        flag=true;
    }
    else
    {
      flag=false;
      break;
    }
        }
    }
    else
    {
        flag=false;
    }
    return flag;
      }
      }
  
}

int main()
{
 int ch;
 long phone;
 char name[20],add[20],email[30];
    cout<<"\n";
    cout<<"\n";
    cout<<"                        **** Welcome to Contact Management System ****\n";
    cout<<"\n";
      // Menu of contact management system
    cout<<"                                           MAIN MENU\n";
    cout<<"                                      ======================\n";
    cout<<"                                      1 Add a new Contact\n";
    cout<<"                                      2 Search for Contact\n";
    cout<<"                                      3 List of all Contacts\n";
    cout<<"                                      4 Update a Contact\n";
    cout<<"                                      5 Delete a Contact\n";
    cout<<"                                      6 Validate Contact number\n";
    cout<<"                                      0 Exit\n";
    cout<<"                                      ======================\n";
    cout<<"                                      Enter the choice:";
    cin>>ch;
    
     switch(ch)
    {
    	case 0: 
        cout<<"\n";
        cout<<"\n";
        cout<<"Thanks you for using the System.....";
    		exit(0);
    			break;
        // case to add contact
    	case 1:Addcontact(phone,name[20],add[20],email[30]);
    		break;

            //case to search a contact
    	case 2:
         int num;
           system("cls");
           cout<<"\nPhone No:";
           cin>>num;
           int sname;
           system("cls");
           cout<<"\nName:";
           cin>>sname;
        Searchcn();
    		break;

            //case to show contact list
   		case 3:
		    Cnlist();
    		break;

            //case to update contact
    	case 4:
        Updatecn();
    		break;

            //case to delete contact
    	case 5:
        Deletecn();
    		break;

            //case to validate contact number
        case 6:
        Validatecn();
        break;

    	default:
    		break;
    }

    return 0;
}
