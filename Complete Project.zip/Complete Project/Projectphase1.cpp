#include<iostream>
#include<iomanip>
#include<fstream>
#include<conio.h>


using namespace std;
// Function to Add a contact
void Addcn(long phone[11],char name[20],char add[20],char email[30]){

            cout<<"Phone No: ";
            cin>>phone[];

            cout<<"Name: ";
           cin.ignore();
            cin>>name;
           
			cout<<"Address: ";
            cin.ignore();
            cin>>add;
           
            cout<<"Email address: ";
            cin.ignore();
            cin>>email;
           
}
// Function to Search for contact

void Searchcn();
// Function to show List of all contacts

void Cnlist();
// Function to Update a contact
void Updatecn();
// Function to Delete a contact

void Deletecn();
// Function to Validate contact number

void Validatecn();

int main()
{
 int ch;
    cout<<"\n";
    cout<<"\n";
    cout<<"                        **** Welcome to Contact Management System ****\n";
    cout<<"\n";
      // Menu of contact management system
    cout<<"                                           MAIN MENU\n";
    cout<<"                                      ======================\n";
    cout<<"                                      1 Add a new contact\n";
    cout<<"                                      2 Search for contact\n";
    cout<<"                                      3 List of all contacts\n";
    cout<<"                                      4 Update a contact\n";
    cout<<"                                      5 Delete a contact\n";
    cout<<"                                      6 Validate contact number\n";
    cout<<"                                      0 Exit\n";
    cout<<"                                      ======================\n";
    cout<<"                                      Enter the choice:";
    cin>>ch;
    
     switch(ch)
    {
    	case 0: 
        cout<<"\n";
        cout<<"\n";
        cout<<"Thanks you for using the System.....";
    		exit(0);
    			break;
        // case to add contact
    	case 1:Addcn();
    		break;
            //case to search a contact
    	case 2:
         int num;
           system("cls");
           cout<<"\nPhone No:";
           cin>>num;
           int sname;
           system("cls");
           cout<<"\nName:";
           cin>>sname;
        Searchcn();
    		break;
            //case to show contact list
   		case 3:
		    Cnlist();
    		break;
            //case to update contact
    	case 4:
        Updatecn();
    		break;
            //case to delete contact
    	case 5:
        Deletecn();
    		break;
            //case to validate contact number
        case 6:
        Validatecn();
        break;
    	default:
    		break;
    }

    return 0;
}
